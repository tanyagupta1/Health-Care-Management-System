def url(s):
    return f"http://testserver{s}"
