from webob import Request as WebObRequest

# temporary alias
Request = WebObRequest
